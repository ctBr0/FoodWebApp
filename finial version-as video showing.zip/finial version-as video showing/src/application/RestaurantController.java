package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class RestaurantController implements Initializable {

    @FXML
    private TableColumn<Restfood,Button> add;

    @FXML
    private TableView<Restfood> animals;

    @FXML
    private Button changemode;

    @FXML
    private TableColumn<Restfood, String> description;

    @FXML
    private TableColumn<Restfood,String> foodname;

    @FXML
    private Button logout;

    @FXML
    private TableColumn<Restfood,Double> price;

    @FXML
    private TableColumn<Restfood,Button> remove;

    @FXML
    private TableColumn<Restfood, Integer> time;
    
    @FXML
    Button b1=new Button("add");
    private void addfunc(ActionEvent event) {
    	int num=0;
    	b1.setText("success");
    	num++;
    }
    Button b2=new Button("remove");
    private void removefunc(ActionEvent event) {
    	int num=0;
    	b1.setText("success");
    	num++;
    }
    
private final ObservableList<Restfood> list = FXCollections.observableArrayList();
        
@Override
public void initialize(URL url, ResourceBundle rb) {

	b1.setOnAction(this::addfunc);
	b2.setOnAction(this::removefunc);
//Restfood(Button add, Button remove, String foodname, double price, int time,String description)
	
	foodname.setCellValueFactory(new PropertyValueFactory<Restfood,String>("foodname"));
	description.setCellValueFactory(new PropertyValueFactory<Restfood,String>("description"));
	price.setCellValueFactory(new PropertyValueFactory<Restfood,Double>("price"));
	add.setCellValueFactory(new PropertyValueFactory<Restfood,Button>("add")); 
	remove.setCellValueFactory(new PropertyValueFactory<Restfood,Button>("remove")); 
	time.setCellValueFactory(new PropertyValueFactory<Restfood,Integer>("time")); 
	
	Restfood f1 =new Restfood(b1,b2, "burger",10,10,"meat,bread,cheese,veges");
	list.add(f1);
	Restfood f2 =new Restfood(b1,b2, "burger",10,10,"meat,bread,cheese,veges");
	Restfood f3 =new Restfood(b1,b2, "burger",10,10,"meat,bread,cheese,veges");
	Restfood f4 =new Restfood(b1,b2, "burger",10,10,"meat,bread,cheese,veges");
	    list.add(f2);
	    list.add(f3);
	    list.add(f4);
	animals.setItems(list);
}

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("afterLogin.fxml");
    }
    @FXML
    void changemode(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("HomePage.fxml");
    }
    
}

