package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ProfileController{
	public ProfileController() throws IOException {
		getProfile();
	}
    @FXML
    private Button homePage;

    @FXML
    private Button shoppingCart;

    @FXML
    private Button orderInformation;

    @FXML
    private Button logout;

    @FXML
    private PasswordField passwordTextField = new PasswordField();

    @FXML
    private TextField userTextField = new TextField();

    @FXML
    private TextField emailTextField = new TextField();

    @FXML
    private TextField phoneNumberTextField = new TextField();
    
    private String newUsername = "";
    private String newPassword = "";
    private String newEmail = "";
    private String newPhone = "";
	
	String originName = "";
	String originPass = "";
	String originEmail = "";
	String originPhone = "";
	
	File file;

	private String inputUsername = "";

	private String inputPassword = "";
	
		
//	/***
//	 * 替换指定文件中的指定内容
//	 * 
//	 * @param filepath
//	 *            文件路径
//	 * @param sourceStr
//	 *            文件需要替换的内容
//	 * @param targetStr
//	 *            替换后的内容
//	 * @return 替换成功返回true，否则返回false
//	 */
	public static boolean replaceFileStr(String filepath, String sourceStr, String targetStr) {
		try {
			FileReader fis = new FileReader(filepath); // 创建文件输入流
			char[] data = new char[1024]; // 创建缓冲字符数组
			int rn = 0;
			StringBuilder sb = new StringBuilder(); // 创建字符串构建器
			// fis.read(data)：将字符读入数组。在某个输入可用、发生 I/O
			// 错误或者已到达流的末尾前，此方法一直阻塞。读取的字符数，如果已到达流的末尾，则返回 -1
			while ((rn = fis.read(data)) > 0) { // 读取文件内容到字符串构建器
				String str = String.valueOf(data, 0, rn);// 把数组转换成字符串
//				System.out.println(str);
				sb.append(str);
			}
			fis.close();// 关闭输入流
			// 从构建器中生成字符串，并替换搜索文本
			String str = sb.toString().replace(sourceStr, targetStr);
			FileWriter fout = new FileWriter(filepath);// 创建文件输出流
			fout.write(str.toCharArray());// 把替换完成的字符串写入文件内
			fout.close();// 关闭输出流
 
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
 
	}
	
	
    @FXML
    void ChangeToHomePageScene(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("HomePage.fxml");
    }

    @FXML
    void ChangeToOIScene(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("OrderInformation.fxml");
    }

    @FXML
    void ChangeToShoppingCartScene(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("ShoppingCart.fxml");
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Main m = new Main();
    	m.changeScene("LogOut.fxml");
    }
    
    @FXML
   public void saveProfile(ActionEvent event) throws IOException {
    	//need to save information to the database
    	//write the profile into the database
    	getProfile();
    }
    public void getProfile() throws IOException {
    	
    	userTextField = new TextField();
    	userTextField.setPromptText("Username");
    	
    	inputUsername = LogInController.user;
		inputPassword = LogInController.userPassword;
		FileReader fr = new FileReader("CustomerInformation.txt");
        BufferedReader br = new BufferedReader(fr);
        String s = br.readLine().trim();
        String typeUsername = "Username: ";
		String typePassword = "Password: ";
        String typeEmail = "Email: ";
		String typePhone = "Phone: ";
		userTextField.setPromptText(inputUsername);
		passwordTextField.setPromptText(inputPassword);
		inputUsername = (new StringBuilder()).append(typeUsername).append(inputUsername).toString();
		inputPassword = (new StringBuilder()).append(typePassword).append(inputPassword).toString();
		System.out.println(inputUsername);
		System.out.println(inputPassword);
	
        long lines = 0;
    	this.file = new File("CustomerInformation.txt");
    	FileReader fileReader = new FileReader(file);
    	//String y = br.readLine().trim();//first line
    	LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
        lineNumberReader.skip(Long.MAX_VALUE);
        lines = lineNumberReader.getLineNumber() + 1;
		System.out.println(lines);
        fileReader.close();
        lineNumberReader.close();
    }
}
        
//        for(int i = 0; i < lines; i++) {
//        	s = br.readLine().trim();
//        	System.out.println(s);
//        	if(br.readLine() == inputUsername) {
//        		System.out.println("在这呢");
//        		s = br.readLine().trim();
//            	System.out.println(s);
//        		s = br.readLine().trim();
//            	System.out.println(s);
//        		originEmail = s;
//        		originEmail = (new StringBuilder()).append(typeUsername).append(originEmail).toString();
//        		emailTextField.setPromptText(s);
//            	s = br.readLine().trim();
//            	System.out.println(s);
//
//            	originPhone = s;
//        		originPhone = (new StringBuilder()).append(typePassword).append(originPhone).toString();
//            	phoneNumberTextField.setPromptText(s);
//            	System.out.println(s);	
//        	} 
//        	
//        }
//        if(userTextField.getText().isEmpty()) {
//			System.out.println("进入了userif");
//			newUsername = s;
//			newUsername = (new StringBuilder()).append(typeUsername).append(newUsername).toString();
//		}
//        if(passwordTextField.getText().isEmpty()) {
//			newPassword = s;
//			newPassword = (new StringBuilder()).append(typePassword).append(newUsername).toString();
//		}
//        if(emailTextField.getText().isEmpty()) {
//			newEmail = s;
//			newEmail = (new StringBuilder()).append(typeEmail).append(newEmail).toString();
//		}
//        if(phoneNumberTextField.getText().isEmpty()) {
//    		newPhone = s;
//    		newPhone = (new StringBuilder()).append(typePhone).append(newPhone).toString();
//		}
//        String spaceline = "\n";
//        String sumOrigin = (new StringBuilder()).append(originName).append(spaceline).append(originPass).append(spaceline).append(originEmail).append(spaceline).append(originPhone).append(spaceline).toString();
//        String sumNew = (new StringBuilder()).append(newUsername).append(spaceline).append(newPassword).append(spaceline).append(newEmail).append(spaceline).append(newPhone).append(spaceline).toString();
//        while(s != null) {
//        	if(s == inputUsername) {
//        		if(s == inputPassword) {
//                    replaceFileStr("CustomerInformation.txt", sumOrigin, sumNew);
//        		}
//        	}
//        }//end of while 	
//        fr.close();
//		br.close();
 //   }
//  }