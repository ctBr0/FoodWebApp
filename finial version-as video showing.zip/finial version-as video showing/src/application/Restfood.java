package application;


import java.time.Duration;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class Restfood {
        Button add;
        Button remove;
	    String foodname;
	    double price;
	    int time;
        String description;
		public Restfood(Button add, Button remove, String foodname, double price, int time,String description) {
			super();
			this.add = add;
			this.remove = remove;
			this.foodname = foodname;
			this.description = description;
			this.price = price;
            this.time = time;
		}
		public Button getAdd() {
			return add;
		}
		public void setAdd(Button add) {
			this.add = add;
		}
		public Button getRemove() {
			return remove;
		}
		public void setRemove(Button remove) {
			this.remove = remove;
		}
		public String getFoodname() {
			return foodname;
		}
		public void setFoodname(String foodname) {
			this.foodname = foodname;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public int getTime() {
			return time;
		}
		public void setTime(int time) {
			this.time = time;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		
}